/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LCD16x2.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t h_mode = 0;
uint8_t Time = 0;
//uint8_t Hour = 0;
uint8_t Temp_Set=20;
uint8_t  NoControl=1;
//int x=0;
uint8_t Room_Temp = 0;
uint8_t Room_Temp_av=0;

uint8_t SetControlLoop = 2;
//uint8_t SetTemperature = 1;
//uint8_t SetMinute = 0;
//uint8_t SetHour = 0;
//char Show_time[6];
uint32_t begin_time = 0;
uint8_t Relay_state = 0;
//uint8_t Zero_Time = 0;
//uint8_t TimeOut = 0;
uint8_t count_trigger=0;
uint8_t nloop=0;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	HAL_Delay(300);

	lcd_init();
	HAL_Delay(300);

	lcd_put_cur(0, 0);
	lcd_send_string(" Control System");
	lcd_put_cur(1, 0);
	lcd_send_string("By:Tina & Mazyar");
	HAL_Delay(1500);
	lcd_clear();

  	HAL_Delay(100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1)
    {
  	  if(SetControlLoop==2)
  	  {
  		  if(NoControl==1){

  			  lcd_put_cur(0, 0);
  			  lcd_send_string("Non-Stop");
  				if (HAL_GPIO_ReadPin(GPIOA, Push_bottun_Pin)
  						== GPIO_PIN_RESET) {
  					HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_SET);
  				}
  		  }
  		  else{
  			  //lcd_clear();
  			  lcd_put_cur(0, 0);
  			  lcd_send_string("Set Role");
  			  if (HAL_GPIO_ReadPin(GPIOA, Push_bottun_Pin) == GPIO_PIN_RESET) {
  				  HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_RESET);
  				  SetControlLoop=1;
  				  lcd_clear();
  			  }
  		  }
  		  if (HAL_GPIO_ReadPin(GPIOA, Set_bottun_Pin) == GPIO_PIN_RESET) {
  		  		//Temp_Set++;
  		  		HAL_Delay(300);
  		  		NoControl=abs(NoControl-1);
  		  		lcd_clear();
  		  }

  	  }
    else if (SetControlLoop == 1) {
  			count_trigger = 0;
  			nloop=0;
  			while (1) {
  				lcd_put_cur(0, 0);
  				lcd_send_string("Set:");
  				Set_Temperature();

  				lcd_put_cur(0, 4);
  				Show_Number(Temp_Set);
  				lcd_put_cur(0, 6);
  				lcd_send_string("C");
  				HAL_Delay(400);
  				lcd_clear();

  				if (HAL_GPIO_ReadPin(GPIOA, Push_bottun_Pin)
  						== GPIO_PIN_RESET) {
  					//SetTemperature = 0;
  					HAL_Delay(250);
  					lcd_clear();
  					break;

  				}
  			}
  			while (1) {
  				lcd_put_cur(0, 0);
  				lcd_send_string("Time:");
  				Set_Time();
  				lcd_put_cur(1, 0);
  				Show_Number(Time);
  				if(h_mode==0){
  				  lcd_put_cur(1, 7);
  			      lcd_send_string("m");

  				}else{
  					lcd_put_cur(1, 7);
  					lcd_send_string("h");

  				}
  				HAL_Delay(400);
  				lcd_clear();

  				if (HAL_GPIO_ReadPin(GPIOA, Push_bottun_Pin)
  						== GPIO_PIN_RESET) {
  					SetControlLoop = 0;
  					//TimeOut=0;
  					HAL_Delay(250);
  					lcd_clear();
  					Relay_state = 1;
  					begin_time = HAL_GetTick() / 1000;
  					break;
  				}
  			}

  		} else {
  			uint8_t Zero_Time = 0;
  			char Show_time[6];
  			if (Relay_state == 1) {
  				HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_SET);
  				//HAL_GPIO_WritePin(GPIOA, LED_Pin_Pin, GPIO_PIN_SET);
  				HAL_Delay(50);
  			} else {
  				HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_RESET);
  			}
  			if (Time == 0) {

  				Show_time[0] = 'N';
  				Show_time[1] = 'o';
  				Show_time[2] = ' ';
  				Show_time[3] = 'T';
  				Show_time[4] = 'i';
  				Show_time[5] = 'm';
  				Show_time[6] = 'e';
  				Show_time[7] = 'r';
  			} else {
  				uint8_t Minute=0;
  				uint8_t Hour=0;
  				if(Time>4){
  					Hour=0;
  					Minute=Time;
  				}else{
  					Hour=Time;
  					Minute=0;
  				}

  				uint32_t a = abs(
  						Hour * 3600 + Minute * 60 + begin_time
  								- HAL_GetTick() / 1000);
  				if (a < 7) {
  					a = 0;
  					Zero_Time = 1;
  				}
  				uint8_t h = a / 3600;
  				uint8_t m = (a - h * 3600) / 60;
  				uint8_t s = (a - m * 60 - h * 3600);
  				sprintf((char*) Show_time, "%02d:%02d:%02d", h, m, s);
  				Off_Relay(Zero_Time);

  			}
  			Calc_Temp();


  			if (nloop > 6) {

  				if (Room_Temp_av < Temp_Set*7-4) {
  					Relay_state = 0;
  					//Show_time[6]="Low";
  				}
  				if (Room_Temp_av > Temp_Set*7+4) {
  					Relay_state = 1;
  				}
  				Room_Temp_av = Room_Temp_av / 7;
  				nloop = 1;
  			}

  //
  			if (HAL_GPIO_ReadPin(GPIOA, Push_bottun_Pin) == GPIO_PIN_RESET) {
  				HAL_Delay(200);
  				count_trigger++;
  				if (count_trigger > 5) {
  					HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_RESET);
  					SetControlLoop = 2;
  					Relay_state = 0;
  					lcd_clear();
  					lcd_put_cur(0, 0);
  					lcd_send_string("Release Button!");
  					HAL_Delay(1000);
  					NoControl=0;
  					lcd_clear();

  				}

  			} else {
  				lcd_put_cur(1, 4);
  				lcd_send_string(Show_time);
  				Show_Conditions(Temp_Set, Room_Temp);
  				HAL_Delay(2000);
  				lcd_put_cur(1, 0);
  				lcd_send_string("                ");
  				HAL_Delay(2000);
  				//lcd_clear();
  				//count_trigger=0;
  			}

  		}

  		/* USER CODE END WHILE */

  		/* USER CODE BEGIN 3 */
  	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSI14;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL4;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|Relay_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Set_bottun_Pin Push_bottun_Pin */
  GPIO_InitStruct.Pin = Set_bottun_Pin|Push_bottun_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA1 PA2 PA3 PA4
                           PA5 PA6 PA7 Relay_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|Relay_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void Set_Temperature(void){
	if (HAL_GPIO_ReadPin(GPIOA, Set_bottun_Pin) == GPIO_PIN_RESET) {
		Temp_Set++;
		HAL_Delay(100);
	}
	if(Temp_Set>29){Temp_Set=20;}
}


void Set_Time(void){
	if (HAL_GPIO_ReadPin(GPIOA, Set_bottun_Pin) == GPIO_PIN_RESET) {
		if (h_mode == 0) {
			Time = Time + 15;
			HAL_Delay(100);
			if (Time > 60) {
				h_mode = 1;
				Time=1;
			}
		} else {
			Time = Time + 1;
			HAL_Delay(100);
			if (Time > 4) {
				h_mode = 0;
				Time = 0;
			}
		}


	}
}



void Show_Number(uint8_t Numb) {

	uint8_t length = 1;
	if (Numb > 9) {
		length = 2;
	}
	char str[length];
	uint8_t var = 0;
	for (var = 0; var < length; ++var) {
		str[var] = 0;
	}
	sprintf(str, "%i", Numb);
	//lcd_put_cur(0, 0);
	lcd_send_string(str);
}
void Show_Conditions(uint8_t T_Set, uint8_t T_Room) {


	lcd_put_cur(0, 0);
	lcd_send_string("Tr:");
	lcd_put_cur(0, 3);
	Show_Number(T_Room);
	lcd_put_cur(0, 5);
	lcd_send_string("C");
	Calc_Temp();

	lcd_put_cur(0, 9);
	lcd_send_string("Set:");
	lcd_put_cur(0, 13);
	Show_Number(T_Set);
	lcd_put_cur(0, 15);
	lcd_send_string("C");
	Calc_Temp();

}
//void Show_Conditions(uint8_t T_Set, uint8_t T_Room) {
//
//
//	lcd_put_cur(0, 0);
//	lcd_send_string("Room:");
//	lcd_put_cur(0, 5);
//	Show_Number(T_Room);
//	lcd_put_cur(0, 7);
//	lcd_send_string("C");
//	HAL_Delay(2000);
//	Calc_Temp();
//	lcd_put_cur(0, 0);
//	lcd_send_string("        ");
//	lcd_put_cur(0, 0);
//	lcd_send_string("Set:");
//	lcd_put_cur(0, 4);
//	Show_Number(T_Set);
//	lcd_put_cur(0, 6);
//	lcd_send_string("C");
//	Calc_Temp();
//
//}
void Calc_Temp(void) {
	// Get ADC value
	HAL_ADC_Start(&hadc);
	HAL_ADC_PollForConversion(&hadc, 1000);
	Room_Temp = (22 * (HAL_ADC_GetValue(&hadc)-86)  - 4040)/1000;
	//Room_Temp = (24 * HAL_ADC_GetValue(&hadc)  - 11480)/1000;

	HAL_ADC_Stop(&hadc);
	Room_Temp_av=Room_Temp+Room_Temp_av;
	nloop++;
}
void Off_Relay(uint8_t Zero_Time) {
	if (Zero_Time == 1) {
		Relay_state = 0;
		SetControlLoop=2;
		HAL_GPIO_WritePin(GPIOA, Relay_Pin, GPIO_PIN_RESET);
		while (1) {
			lcd_put_cur(0, 0);
			lcd_send_string("Off");
		}

		//TimeOut = 1;
		//bigin_time=HAL_GetTick()/1000;
	}

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
